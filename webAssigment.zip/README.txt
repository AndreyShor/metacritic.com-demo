How to set up ?

1. Run all code in start.sql
2. Admin account:
    username: root
    passwordL 12345

3. How to add article ?
    1. Admin -> add article 
    2. Important, you must feel all options and select category
    3. Don't use the same image twice - will be error

[CODE allocation]
CSS code in min format, use "Beautify" or other tool to make it "line by line with spaces"


What functionality was implemented ?

* Login / Registred
* crypto of user password
* 3 types of users:
    1. non-reg
    2. reg
    3. Admin
* Admin panel:
    0. Fetch Article and Users
    1. Add Article 
    2. Delete Article
    3. Edit Article

    4. Delete user 
    5. Edit user
* Article:
    1. Filter article by genre
    2. See all articles from DB (It is a lot of work)
    3. Add review to article
    4. User can put his review only once
    5. For each page fetch review(comments)

* Architecture of application 
    1. I was writting code in OOP style and use MVC 

Finally: You must pay students for this project, too much work for 1 person :D

