<footer>
    <div class="upper">
        <div class="logo">
            <h3>Creator: Andrey Shorstkin</h3>
            <h2>Online Blog, Essex Uni. Project</h2>
        </div>
        <ul class="footer_menu">
            <li class="item"><a href="">Main Page</a></li>
            <li class="item"><a href="">Admin Page</a></li>
            <li class="item"><a href="">Login</a></li>
            <li class="item"><a href="">Register</a></li>
        </ul>
    </div>
    <div class="lower">
        <ul class="copyright">
            <li>Address: Colchester, UK </li>
            <li>Andrey: andrejs232@gmail.com</li>
            <li>© Copyright 2019</li>
        </ul>
    </div>
</footer>